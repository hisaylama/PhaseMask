%Function file for circular lattice

 %size of the frame = [L/2, L/2 - dx]
function [I] = Circle_spot(M, N, S_L, P)
psize = 20e-6;%(in m)
w=1*psize; %half width of the spot (px) 
x1=([0.5:1:M-0.5] - M/2)*psize;
y1 =([0.5:1:N-0.5] - N/2)*psize;
[X1,Y1]=meshgrid(x1,y1);
P1 = P*psize;
I = 0;

for i = [1:1:S_L]
    %I = 0;
    %u1=circ((sqrt((X1- M /2 - P.*cos(i*pi./(S_L./2))).^2 + (Y1 - N /2 - P.*sin(i.*pi./(S_L./2))).^2))./w);
    u1=circ((sqrt((X1- P1.*cos(i*pi./(S_L./2))).^2 + (Y1 - P1.*sin(i.*pi./(S_L./2))).^2))./w);
    I = I + abs(u1.^2); 
    
 end

end


 