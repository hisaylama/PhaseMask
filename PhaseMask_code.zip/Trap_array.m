%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Generating an array of optical traps in the focal plane
%author - Hisay Lama
%email ID - hisaylama@gmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear,  clc,
close all,
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%specification of slm
M = 792; %input('M = ');%SLM pixel rows
N = 600; %input('N = ');%SLM pixel colums
psize = 20e-6; %input('psize = ');%pixelsize [m]
lambda = 1064e-9; %input('lambda = '); %light wavelength [m]
levels = 255;%input('input levels = '); %number of gray level for 2pi modulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%incoming beam (after circular iris)
R = 5e-3;
E0 = zeros(N,M);
[X,Y] = meshgrid(([0.5:1:M-0.5] - M/2)*psize, ([0.5:1:N-0.5] - N/2)*psize);
E0(X.^2+Y.^2<R^2) = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Beam at the focal plane
c0 = 3e8; %speed of light in vaccum
e0 = 8.86e-12; %dielectric constant in vaccum
f = input('focal length, f = ');%focal length
z = input('z = '); %distance from fous
k = 2*pi/lambda;%wave vector
[fx,fy] = meshgrid((1/psize).*[-M/2:1:M/2-1]/M,(1/psize)*[-N/2:1:N/2-1]/N);%frequency size
x = lambda*f*fx;
y = lambda*f*fy;
r = hypot(X,Y); %(sqrt(X.^2 + Y.^2))
s = zeros(size(X));
%alpha_vec = input('[alpha] = ');%[alpha] = [0.1 0.2 0.4 0.5]*pi/180
n_max = 6;
for n = 1:1:n_max
    alpha_vec(n) = (((n -1).*20)./z)*pi/180;
end
%phi_vec = input('[phi] = '); % [alpha] = [10 20 30 90]*pi/180
for n =1:1:n_max
    phi_vec(n) = pi/2;
end 
Lambda = lambda./tan(alpha_vec); %Grating length
phase0_vec = zeros(size(alpha_vec));
for i = 1:1:length(alpha_vec)
    if alpha_vec(i)~=0
        s = s + exp( ...
            2*pi*1i*mod(cos(phi_vec(i)).*X+sin(phi_vec(i)).*Y,Lambda(i))/Lambda(i) ...
            + 1i*mod(2*pi*r.^2/(2*lambda*f),2*pi) ...
            + 1i*phase0_vec(i) ...
            );
    else
        s = s + exp( ...
            1i*mod(2*pi*r.^2/(2*lambda*f),2*pi) ...
            + 1i*phase0_vec(i) ...
            );
    end
end
phase = angle(s);
%phase = mod(2*pi*r.^2/(2*lambda*f),2*pi);%phase due to the Fresnel lens
Efocus = exp(1i*k*(2*f+z + x.^2 + y.^2))/(1i*lambda*f).*fftshift(fft2(E0.*exp(1i*phase).*exp(-1i*pi*z/(lambda*f^2)*(X.^2+Y.^2))));
Ifocus = (c0*e0/2)*abs(Efocus.^2); %PhysConst.c0*PhysConst.e0/2*
figure(1)
%surf(X*1e+3,Y*1e+3,Ifocus)
surface(Ifocus)
colormap(gray(255))
shading interp
%xlabel('x [mm]')
%ylabel('y [mm]')
figure(2)
image(phase/(2*pi)*255)
colormap(gray(255))
axis equal tight
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%