%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Evaluate Laguerre Gauss beam for symboLic function
%E_Lp (rho, phi)
%rho^2 = (x^2 + y^2)
%L,p is node and order
%AmpLitude = 1 (say)
%Beam waist = 0.5 - 1(unit)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close aLL,
clear
clc
L = input('number of nodes aLong the radiaL direction  = ');
p = input('phase singuLarity order =  ');
w = input('beam waist =  '); % less than 50, wasit in pixel unit
M = 800; %side length (pixel unit)
N = 600; % side length (pixel unit)
psize = 20e-6; %pxiel size (m)
xx = ([0.5:1:M-0.5] - M/2);
yy = ([0.5:1:N-0.5] - N/2);
[x,y] = meshgrid(xx,yy);
z = (x.^2 + y.^2)./(w^2);
Lz = laguerreL(p,L,2.*z);
c = sqrt(factorial(p)./(3.14.*factorial(abs(L)+p)));
Phi = (abs(L).*atan2(y,x));
u_in = c.*((sqrt(2).*sqrt(z)).^abs(L)).*Lz.*exp(-z).*exp(1j.*Phi);
%L_Gp = u_in.*conj(u_in);
L_Gp = abs(u_in);
Phase = mod(angle(u_in),2*pi);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
xlabel('E(x,y)')
xlim([1 length(xx)]);ylim([1 length(yy)]);
surface(L_Gp)
%surf(xx,yy,zz, L_Gp)
axis equal
colormap(gray)
colorbar()
shading interp 
axis off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2)
xlabel('Phase')
xlim([1 length(xx)]);ylim([1 length(yy)]);
surface(Phase)
axis equal
colormap(gray)
colorbar()
shading interp 
axis off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%